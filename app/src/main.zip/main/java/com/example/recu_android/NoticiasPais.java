package com.example.recu_android;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

public class NoticiasPais extends AppCompatActivity {

    private Button btnVolver;
    private ListView lvLista;
    private TextView tvLocalidad;
    private Spinner spinnerLocalidades;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noticias_pais);

        btnVolver = findViewById(R.id.btnVolver);
        lvLista = findViewById(R.id.lvLista);
        tvLocalidad = findViewById(R.id.tvLocalidad);

        spinnerLocalidades = findViewById(R.id.spinnerLocalidades);


        String[] localidades = {"Elige", "Andalucia", "Cataluna", "Madrid"};

        // Crea un ArrayAdapter para el Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, localidades);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerLocalidades.setAdapter(adapter);

        // Configura el listener del Spinner
        spinnerLocalidades.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                // Actualiza el TextView con la localidad seleccionada
                String texto = "Noticias de ... " + localidades[position];
                tvLocalidad.setText(texto);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Puedes dejar este método vacío si no necesitas implementar ninguna acción aquí
            }
        });

        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
/*    public void cargarXMLConSAX (View v){
        //Carga de XML mediante Tarea Asincrona
        /*CargarXmlTask tarea = new CargarXmlTask();
        tarea.execute(url);
    }*/

