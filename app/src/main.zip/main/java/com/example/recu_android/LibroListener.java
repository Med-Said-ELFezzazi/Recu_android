package com.example.recu_android;

public interface LibroListener {
    void onLibroSeleccionado(Libro l);
}
