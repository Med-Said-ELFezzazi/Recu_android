package com.example.recu_android;

import androidx.appcompat.app.AppCompatActivity;


import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ListadoLibros  extends AppCompatActivity implements LibroListener{

    private Button btnVolver;
    public static Libro[] libros;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listado_libros);

        btnVolver = findViewById(R.id.btnvolver);
        BibliotecaSQLiteHelper bibliodbh =
                new BibliotecaSQLiteHelper(this, "DBBiblio", null, 1);
        libros = BibliotecaDAO.arrayLibros(bibliodbh);
        FragmentListado fragmentListado =
                (FragmentListado)getSupportFragmentManager().
                        findFragmentById(R.id.frgListado);
        fragmentListado.setLibroListener(this);
        System.out.println(libros[0]);
        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                finish();
            }
        });
    }

    @Override
    public void onLibroSeleccionado(Libro l) {
        boolean hayDetalle =
                (getSupportFragmentManager().findFragmentById(R.id.frgDetalle)!= null);
        if (hayDetalle) {
            ((FragmentDetalle)getSupportFragmentManager().
                    findFragmentById(R.id.frgDetalle)).mostrarDetalle(l.getTitulo()+"\n"+l.getTitulo()+"\n"+l.getIsbn()+"\n"+l.getEditorial());
        }
        else {
            Intent i = new Intent(this, DetalleActivity.class);
            i.putExtra(DetalleActivity.EXTRA_TEXTO, l.getTitulo()+"\n"+l.getTitulo()+"\n"+l.getIsbn()+"\n"+l.getEditorial());
            startActivity(i);
        }
    }
}